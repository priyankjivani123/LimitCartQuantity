<?php

namespace Vdcstore\LimitCart\Block\Adminhtml\Form\Field;

use Magento\Framework\View\Element\Html\Select;

use Magento\Backend\Block\Template\Context;
use Magento\Customer\Model\Customer\Attribute\Source\GroupSourceLoggedInOnlyInterface;
use Magento\Framework\App\ObjectManager;

/**
 *
 */
class CustomColumn extends Select
{
    /**
     * @var GroupSourceLoggedInOnlyInterface|mixed
     */
    protected $groupdata;

    /**
     * @param Context $context
     * @param GroupSourceLoggedInOnlyInterface|null $groupdata
     * @param array $data
     */
    public function __construct(Context $context, GroupSourceLoggedInOnlyInterface $groupdata = null, array $data = [])
    {
        $this->groupdata = $groupdata
            ?: ObjectManager::getInstance()->get(GroupSourceLoggedInOnlyInterface::class);
        parent::__construct($context, $data);
    }

    /**
     * @param $value
     * @return mixed
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * @param $value
     * @return CustomColumn
     */
    public function setInputId($value)
    {
        return $this->setId($value);
    }

    /**
     * @return string
     */
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            $this->setOptions($this->getSourceOptions());
        }
        return parent::_toHtml();
    }

    /**
     * @return array
     */
    private function getSourceOptions()
    {
        $customerGroups = $this->groupdata->toOptionArray();
        $customerGroups[] = ['value' => '0', 'label' => 'NOT LOGGED IN'];
        return $customerGroups;
    }
}
