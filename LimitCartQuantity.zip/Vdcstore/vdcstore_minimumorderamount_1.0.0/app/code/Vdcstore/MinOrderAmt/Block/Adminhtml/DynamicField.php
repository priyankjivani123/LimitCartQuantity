<?php

namespace Vdcstore\MinOrderAmt\Block\Adminhtml;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;
use Magento\Framework\DataObject;
use Vdcstore\MinOrderAmt\Block\Adminhtml\Form\Field\CustomColumn;

/**
 *
 */
class DynamicField extends AbstractFieldArray
{
    /**
     * @var
     */
    private $dropdownRenderer;

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function getDropdownRenderer()
    {
        if (!$this->dropdownRenderer) {
            $this->dropdownRenderer = $this->getLayout()->createBlock(
                CustomColumn::class,
                '',
                ['data' => ['is_render_to_js_template' => true]]);
        }
        return $this->dropdownRenderer;
    }

    /**
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareToRender()
    {

        $this->addColumn(
            'attribute_name',
            [
                'label' => __('Customer Group'),
                'renderer' => $this->getDropdownRenderer(),
            ]
        );
        $this->addColumn(
            'dropdown_field',
            [
                'label' => __('Purchaseover'),
                'class' => 'required-entry',

            ]
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Customer Groups');
    }

    /**
     * @param DataObject $row
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Zend_Log_Exception
     */
    protected function _prepareArrayRow(DataObject $row)
    {
        $optionExtraAttr = [];
        $optionExtraAttr['option_' . $this->getDropdownRenderer()->calcOptionHash($row->getData('dropdown_field'))] = 'selected="selected"';
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );
    }
}
