<?php

namespace Vdcstore\MinOrderAmt\Helper;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Backend\Model\Session\Quote as BackendQuote;
use Magento\Checkout\Model\Session as FrontendQuote;
use Magento\Customer\Model\Context;
use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;

/**
 *
 */
class Data extends AbstractHelper
{

    /**
     *
     */
    const XML_PATH_MINORDERAMT = 'minorder_amt/';
    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;

    /**
     * @var BackendQuote
     */
    public $backendQuoteSession;

    /**
     * @var FrontendQuote
     */
    public $frontendQuoteSession;

    /**
     * @var Session
     */
    public $customerSession;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    public $httpContext;

    /**
     * @var State
     */
    public $state;

    /**
     * @var array
     */
    public $productCache = [];

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param BackendQuote $backendQuoteSession
     * @param FrontendQuote $frontendQuoteSession
     * @param Session $customerSession
     * @param State $state
     */
    public function __construct(
        ScopeConfigInterface                $scopeConfig,
        \Magento\Framework\App\Http\Context $httpContext,
        BackendQuote                        $backendQuoteSession,
        FrontendQuote                       $frontendQuoteSession,
        Session                             $customerSession,
        State                               $state
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->httpContext = $httpContext;
        $this->backendQuoteSession = $backendQuoteSession;
        $this->frontendQuoteSession = $frontendQuoteSession;
        $this->customerSession = $customerSession;
        $this->state = $state;
    }

    /**
     * @return int|mixed|null
     * @throws LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentCustomerGroup()
    {
        $customerGroupId = $this->httpContext->getValue(Context::CONTEXT_GROUP);

        if (
            !$customerGroupId
            && $this->state->getAreaCode() != Area::AREA_ADMINHTML
        ) {
            $customerGroupId = $this->customerSession->getCustomerGroupId();
        }

        // Only run this code if there is an active admin quote
        if (
            !$customerGroupId
            && $this->backendQuoteSession->getQuoteId()
            && $this->state->getAreaCode() == Area::AREA_ADMINHTML
        ) {
            $customerGroupId = $this->backendQuoteSession->getQuote()->getCustomerGroupId();
        }

        return $customerGroupId;
    }

    /**
     * @param $field
     * @param $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field, ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    /**
     * @param $code
     * @param $storeId
     * @return mixed
     */
    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_MINORDERAMT . 'general/' . $code, $storeId);
    }

}
