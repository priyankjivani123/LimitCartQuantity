<?php

namespace Vdcstore\MinOrderAmt\Observer;

use Magento\Customer\Model\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\View\Result\PageFactory;
use Psr\Log\LoggerInterface;
use Magento\Catalog\Model\Attribute\Config;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\App\ResponseFactory;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\MinOrderAmt\Helper\Data;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Serialize\SerializerInterface;

/**
 *
 */
class CheckShoppingCartObserver implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Session
     */
    protected $_session;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var PriceCurrencyInterface
     */
    protected $_priceCurrency;

    /**
     * @var RedirectInterface
     */
    protected $redirect;

    /**
     * @var ProductRepository
     */
    protected $_productRepository;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var Config
     */
    protected $_config;

    /**
     * @var Cart
     */
    protected $cart;

    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var ResponseFactory
     */
    protected $_responseFactory;

    /**
     * @var UrlInterface
     */
    protected $_url;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param Session $session
     * @param LoggerInterface $logger
     * @param PageFactory $resultPageFactory
     * @param PriceCurrencyInterface $priceCurrency
     * @param SerializerInterface $serializer
     * @param ManagerInterface $messageManager
     * @param ResponseFactory $responseFactory
     * @param UrlInterface $url
     * @param Cart $cart
     * @param ProductRepository $productRepository
     * @param StoreManagerInterface $storeManager
     * @param Config $config
     * @param RedirectInterface $redirect
     * @param Data $helper
     */
    public function __construct(
        \Magento\Framework\App\Http\Context        $httpContext,
        Session            $session,
        LoggerInterface                            $logger,
        PageFactory $resultPageFactory,
        PriceCurrencyInterface                     $priceCurrency,
        SerializerInterface                        $serializer,
        ManagerInterface                           $messageManager,
        ResponseFactory                            $responseFactory,
        UrlInterface                               $url,
        Cart                                       $cart,
        ProductRepository                          $productRepository,
        StoreManagerInterface                      $storeManager,
        Config                                     $config,
        RedirectInterface                          $redirect,
        Data                                       $helper
    )
    {
        $this->httpContext = $httpContext;
        $this->_session = $session;
        $this->logger = $logger;
        $this->_priceCurrency = $priceCurrency;
        $this->serializer = $serializer;
        $this->messageManager = $messageManager;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->cart = $cart;
        $this->_productRepository = $productRepository;
        $this->_storeManager = $storeManager;
        $this->redirect = $redirect;
        $this->_config = $config;
        $this->helper = $helper;
        $this->resultPageFactory = $resultPageFactory;

    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $currency = $this->_priceCurrency->getCurrency()->getCurrencySymbol();
        $enable = $this->helper->getGeneralConfig('enable');
        $cartprice = '';
        $cartprice = $this->cart->getQuote()->getSubtotal();
        $field = $this->helper->getGeneralConfig('dynamic_field');
        $serialize = $this->serializer->unserialize($field);
        $explodcustomers = explode(',', $field);
        $current = $this->helper->getCurrentCustomerGroup();

        if ($enable == '1') {
            foreach ($serialize as $val) {
                $attribute = $val['attribute_name'];
                $dropdown = $val['dropdown_field'];
                if ($attribute == $current) {
                    if ($dropdown > $cartprice && $dropdown != $cartprice) {
                        $message = $this->helper->getGeneralConfig('alertmsg') . $currency . $dropdown;
                        $this->messageManager->addError($message);
                        $cartUrl = $this->_url->getUrl('checkout/cart/index');
                        $this->_responseFactory->create()->setRedirect($cartUrl)->sendResponse();
                        exit;
                    }
                }
            }
        }
    }
}


